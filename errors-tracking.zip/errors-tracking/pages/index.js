export default function Home() {
  return (
    <div style={{ padding: "50px", textAlign: "center" }}>
      <h1>Welcome to Errors Tracking App</h1>
      <p>This is your Vercel-ready Next.js app.</p>
    </div>
  );
}