# Errors Tracking App (Fullstack)

## Overview
Simple errors tracking app with roles (admin/manager/analyst), JWT auth, SQLite DB, and a React frontend (Vite).

## Requirements
- Node.js >= 18
- npm or yarn

## Install & Run

### Backend
```bash
cd backend
npm install
# initialize DB (first run)
node server.js --init
# then start server
node server.js
# or: npm start
