const express = require('express');
const router = express.Router();
const { run, all, get } = require('../db');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'replace_this_secret';

// middleware to verify token
function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'Missing auth' });
  const parts = header.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'Invalid auth' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// create error
router.post('/', auth, async (req, res) => {
  const { employee, description, timestamp } = req.body;
  if (!employee || !description) return res.status(400).json({ error: 'Missing fields' });
  const ts = timestamp || new Date().toISOString();
  try {
    const r = await run('INSERT INTO errors (employee, description, timestamp, created_by) VALUES (?,?,?,?)', [employee, description, ts, req.user.username]);
    res.json({ ok: true, id: r.lastID });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// list errors (with optional search)
router.get('/', auth, async (req, res) => {
  const q = (req.query.q || '').trim();
  const sql = q
    ? `SELECT * FROM errors WHERE employee LIKE ? OR description LIKE ? ORDER BY id DESC`
    : `SELECT * FROM errors ORDER BY id DESC`;
  const params = q ? ['%' + q + '%', '%' + q + '%'] : [];
  try {
    const rows = await all(sql, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// get one by id
router.get('/:id', auth, async (req, res) => {
  try {
    const row = await get('SELECT * FROM errors WHERE id=?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// delete (admin or creator only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const row = await get('SELECT * FROM errors WHERE id=?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    if (req.user.role !== 'admin' && req.user.username !== row.created_by) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    await run('DELETE FROM errors WHERE id=?', [req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
