const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { db, run } = require('./db');

const authRoutes = require('./routes/auth');
const errorsRoutes = require('./routes/errors');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(bodyParser.json());

// init DB if requested
if (process.argv.includes('--init')) {
  const sql = fs.readFileSync(path.join(__dirname, 'migrations', 'init.sql'), 'utf8');
  db.exec(sql, (err) => {
    if (err) console.error('DB init error', err);
    else {
      console.log('DB initialized.');
      // create default users if not exists
      const bcrypt = require('bcrypt');
      (async () => {
        const salt = 10;
        const adminHash = await bcrypt.hash('admin123', salt);
        const managerHash = await bcrypt.hash('manager123', salt);
        const analystHash = await bcrypt.hash('analyst123', salt);
        db.run(`INSERT OR IGNORE INTO users (username,password,role) VALUES ('admin', ?, 'admin')`, adminHash);
        db.run(`INSERT OR IGNORE INTO users (username,password,role) VALUES ('manager', ?, 'manager')`, managerHash);
        db.run(`INSERT OR IGNORE INTO users (username,password,role) VALUES ('analyst', ?, 'analyst')`, analystHash);
        console.log('Default users created if missing.');
      })();
    }
  });
}

// routes
app.use('/api/auth', authRoutes);
app.use('/api/errors', errorsRoutes);

// simple health
app.get('/api/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
